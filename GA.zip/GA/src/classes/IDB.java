package classes;

/**
 *
 * @author Joaquim Alves
 */
public class IDB {
    
    private int[] vetor;
    private int tamGrup; 
    public IDB(int[] v){
        this.vetor = v;
        this.tamGrup = 25;
    }
    
    public void executarIDB(){
        
        int index = 0;
        
        int[] grupo1 = new int[tamGrup];
        int[] grupo2 = new int[tamGrup];
        int[] grupo3 = new int[tamGrup];
        int[] grupo4 = new int[tamGrup];
        
        for (int i=0; i <= 24; i++) {
            grupo1[index] = this.vetor[i];
            index++;
        }
        index = 0;
        for (int i=25; i <= 49; i++) {
            grupo2[index] = this.vetor[i];
            index++;
        }
        index = 0;
        for (int i=50; i <= 74; i++) {
            grupo3[index] = this.vetor[i];
            index++;
        }
        index = 0;
        for (int i=75; i <= 99; i++) {
            grupo4[index] = this.vetor[i];
            index++;
        }
        
        //listar(grupo1);
        //listar(grupo2);
        //listar(grupo3);
        //listar(grupo4);
        
        daviesBoundin(grupo1,grupo2,grupo3,grupo4);
        
    }
    
    private void listar(int[] g){
        System.out.print("Grupo [");
        for (int i=0; i <= 24; i++) {
            System.out.print(g[i]+" ");
        }
        System.out.print("]\n");
    }
    
    private void daviesBoundin(int[] g1, int[] g2, int[] g3, int[] g4) {
        
        int k = 4;
        
        double cent_gr1 = calcularCentroide(g1);
        double cent_gr2 = calcularCentroide(g2);
        double cent_gr3 = calcularCentroide(g3);
        double cent_gr4 = calcularCentroide(g4);
        
        double dispGrup1 = calcularDispersao(g1, cent_gr1);
        double dispGrup2 = calcularDispersao(g2, cent_gr2);
        double dispGrup3 = calcularDispersao(g3, cent_gr3);
        double dispGrup4 = calcularDispersao(g4, cent_gr4);
        
        // calcular distancia entre agrupamentos
        
        double dispGrup1_2 = dispersaoEntreAgrupamentos(dispGrup1, dispGrup2, distanciaEntreGrupos(cent_gr1, cent_gr2));
        double dispGrup1_3 = dispersaoEntreAgrupamentos(dispGrup1, dispGrup3, distanciaEntreGrupos(cent_gr1, cent_gr3));
        double dispGrup1_4 = dispersaoEntreAgrupamentos(dispGrup1, dispGrup4, distanciaEntreGrupos(cent_gr1, cent_gr4));
        
        double R1j = maiorValor_Rij(dispGrup1_2, dispGrup1_3, dispGrup1_4);
        
        double dispGrup2_1 = dispersaoEntreAgrupamentos(dispGrup2, dispGrup1, distanciaEntreGrupos(cent_gr2, cent_gr1));
        double dispGrup2_3 = dispersaoEntreAgrupamentos(dispGrup2, dispGrup3, distanciaEntreGrupos(cent_gr2, cent_gr3));
        double dispGrup2_4 = dispersaoEntreAgrupamentos(dispGrup2, dispGrup4, distanciaEntreGrupos(cent_gr2, cent_gr4));
        
        double R2j = maiorValor_Rij(dispGrup2_1, dispGrup2_3, dispGrup2_4);
        
        double dispGrup3_1 = dispersaoEntreAgrupamentos(dispGrup3, dispGrup1, distanciaEntreGrupos(cent_gr3, cent_gr1));
        double dispGrup3_2 = dispersaoEntreAgrupamentos(dispGrup3, dispGrup2, distanciaEntreGrupos(cent_gr3, cent_gr3));
        double dispGrup3_4 = dispersaoEntreAgrupamentos(dispGrup3, dispGrup4, distanciaEntreGrupos(cent_gr3, cent_gr4));
        
        double R3j = maiorValor_Rij(dispGrup3_1, dispGrup3_2, dispGrup3_4);
        
        double dispGrup4_1 = dispersaoEntreAgrupamentos(dispGrup4, dispGrup1, distanciaEntreGrupos(cent_gr4, cent_gr1));
        double dispGrup4_2 = dispersaoEntreAgrupamentos(dispGrup4, dispGrup2, distanciaEntreGrupos(cent_gr4, cent_gr2));
        double dispGrup4_3 = dispersaoEntreAgrupamentos(dispGrup4, dispGrup3, distanciaEntreGrupos(cent_gr4, cent_gr3));
        
        double R4j = maiorValor_Rij(dispGrup4_1, dispGrup4_2, dispGrup4_3);
        
        
        double DB = (R1j + R2j + R3j + R4j)/4;
        
        System.out.println("VALOR DO IDB = " + DB);
    }
    
    private double maiorValor_Rij(double x, double y, double z){
        double maior = 0;
        
        if(x > y && x > z){ maior = x; }
        else if(y > x && y > z) { maior = y; }
        else if(z > x && z > y) { maior = z; }
        
        return maior;
    }
    
    private double dispersaoEntreAgrupamentos(double dispGi, double dispGj, double distEucGij){
        return (dispGi + dispGj)/distEucGij;
    }
    
    private double calcularDispersao(int[] grupo, double centroide){
        
        double dispersao = 0;
        double aux;
        
        for(int i=0; i < grupo.length; i++){
            aux = (double)grupo[i];
            dispersao += distanciaEuclidiana(aux, centroide);
        }
        
        return dispersao/grupo.length;
    }
    
    private double distanciaEuclidiana(double elemento, double centroide){
        return Math.sqrt(Math.pow(elemento-centroide, 2));
    }
    
    private double calcularCentroide(int[] grupo){
        
        int soma = 0;
        
        for(int i=0; i < grupo.length; i++){
            soma += grupo[i];
        }
        return (double) soma/tamGrup;
    }
    
    private double distanciaEntreGrupos(double centroideGi, double centroideGj){
        return distanciaEuclidiana(centroideGi, centroideGj);
    }
    
}
