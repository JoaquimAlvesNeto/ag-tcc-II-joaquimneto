package classes;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

public class Main {
	public static void main(String args[]) throws IOException {
            final int num_geracoes = 10;
            final int tam_populacao = 100;
            final double prob_mutacao = 0.01;
            //GA meuGA=new GA(num_geracoes,tam_populacao,prob_mutacao);
            //meuGA.executa();
            //ElementoGA pai = new ElementoGA();
            //pai.inicializaElemento(100);
            //pai.contagemCaracteres();
            //System.out.println(pai.valor);
            //System.out.println("RESULTADO FINAL: " + pai.calculo_distribuicao_turma_A());

	}
}