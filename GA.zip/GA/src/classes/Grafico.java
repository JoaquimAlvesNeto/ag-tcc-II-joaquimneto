package classes;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class Grafico {
    
    JFreeChart grafico;
    DefaultCategoryDataset ds = new DefaultCategoryDataset();
    
    public Grafico() throws FileNotFoundException, IOException{
        
        setDados();
        
        this.grafico  = ChartFactory.createLineChart("Gráfico - Avaliação Populacional", "Geração","Avaliação", ds, PlotOrientation.VERTICAL, true, true, false);
        
        OutputStream arquivo = new FileOutputStream("grafico.png");
        ChartUtilities.writeChartAsPNG(arquivo, grafico, 550, 400);
        arquivo.close();
    }
    
    public void setDados(){
        ds.addValue(10.5, "maximo", "dia 1");
        ds.addValue(28.2, "maximo", "dia 2");
        ds.addValue(37.3, "maximo", "dia 3");
        ds.addValue(91.5, "maximo", "dia 4");
        ds.addValue(75.7, "maximo", "dia 5");
        ds.addValue(12.8, "maximo", "dia 6");
    }
    
}
